<%*
// --- Prompts (run once at note creation) ---
const proj   = await tp.system.prompt("Project slug (kebab-case, e.g. foo-tools)");
const title  = await tp.system.prompt("Plan title", `${proj} — Core Plan`);
const scope  = await tp.system.prompt("Scope in one phrase (e.g. shared-core-only)", "core-only");
const finish = await tp.system.prompt("Target finish (MM/DD/YYYY)", tp.date.now("MM/DD/YYYY", 120));
// Rename the note to the plan title so the file and the title property match.
await tp.file.rename(title);
-%>
---
title: <% title %>
type: project-plan
project: <% proj %>
scope: <% scope %>
status: in-progress
created: <% tp.date.now("MM/DD/YYYY") %>
target_finish: <% finish %>
tags:
  - project/<% proj %>
  - plan
  - learning
---

# <% title %>

> [!info] Scope
> This plan covers **<one phrase — what's in scope>** — from <starting point> through <the deliverable boundary>. <What deliberately lives in a separate plan and gets written later.>
>
> Companion documents:
> - [[<% proj %> - Master Schedule]] — week-by-week mapping of *this plan* to your calendar's study + build blocks.
> - [[<project landing note>]] — the project landing note.

> [!note] How to read this
> Each phase has three layers: what you're building, what you're learning, and why this ordering. Phases are dependency-ordered, not calendar-dated; see [[<% proj %> - Master Schedule]] for week-by-week pacing. A phase is done when its exit criteria are met, not when a week ends.

> [!warning] About pacing
> Your primary learning resource is paced for readers, not project-builders. Do the exercises and the matching companion drills *before* applying a topic to the project.

> [!tip]- Revision log
> - **<% tp.date.now("YYYY-MM-DD") %>** — Plan created.

## Languages and concepts in scope for *this* plan

You don't need <downstream skills / later-phase tech> yet — those come after Phase <N>.

- **<Primary language>.** Primary teacher: <book or course>. Companion drill: <exercise set> — do the exercises matching each chapter as you finish it. Reference: <docs / language reference> (lookup only).
- **<Secondary language> — minimal.** You'll only <where and how little it's used>. <Which subset is enough; what you can safely ignore at this stage.>
- **<Scripting / tooling language>.** You're already comfortable. Used here only for <narrow purpose>. Discipline: <conventions to hold to>.
- **<Cross-cutting concept / FFI / protocol>.** No book — concepts only, learned alongside <the chapter or task that needs it>. Concepts: <list the handful of ideas that matter>.

> [!note] <Domain> internals
> You'll learn <the domain-specific knowledge> *while building*, not as a separate study track. Reference: <primary doc / source>, plus the reading you've already started.

## Phase 0 — <name> (pre-flight)

**Goal:** <one sentence — what exists at the end of this phase, before any real feature code.>

**<Primary resource> chapters in scope:** <chapters / modules that back this phase>.

**You're building**
- <the workspace / repo skeleton / scaffolding>
- <a `.gitignore` and the baseline project files>
- <the first architecture decision records (ADRs) at a high level — details deferred to a later phase>
- <a stub README in your own words>
- <a working-journal note started in this vault>

**You're learning**
- <chapter / topic> — <what + the companion drill that matches it>
- <a focused reading list — read it as a critic, noting concrete patterns/anti-patterns to look for later>

**Exit criteria**
- <a single concrete command that proves the skeleton runs, e.g. `cmd run` prints "hello">
- <ADRs 1–N are committed>
- <you've finished the reading list and logged ≥N concrete observations>

> [!note] Why this ordering
> <Why this phase has to come first: what nothing else can start without.>

## Phase 1 — <name>

**Goal:** <one sentence.>

**<Primary resource> chapters in scope:** <chapters>.

**You're building**
- <deliverable>
- <deliverable>

**You're learning**
- <chapter / topic> — <what + companion drill>
- <concept or reading>

**Exit criteria**
- <concrete, testable criterion>
- <criterion>

> [!note] Why this ordering
> <What earlier phase this depends on, and what later phase depends on it.>

## Phase 2 — <name>

**Goal:** <one sentence.>

**<Primary resource> chapters in scope:** <chapters>.

**You're building**
- <deliverable>

**You're learning**
- <chapter / topic> — <what + companion drill>

**Exit criteria**
- <criterion>

> [!note] Why this ordering
> <Dependency rationale.>

<!-- Duplicate a Phase block for each additional phase. Keep phases dependency-ordered; let the Master Schedule handle the calendar. -->

## Final phase — <name>

**Goal:** <one sentence — the capstone that proves the whole scope works end-to-end.>

**<Primary resource> chapters in scope:** <final / advanced chapters>.

**You're building**
- <the integrating deliverable that exercises everything built in earlier phases>

**You're learning**
- <the hardest concepts, which you deliberately deferred until you needed them>

**Exit criteria**
- <an end-to-end test or demo that drives the full feature set>
- <quality gate, e.g. zero leaks / all checks green>

**End of <% scope %> scope.** <One line on what is now stable and what lives in a separate plan beyond here.>

> [!note] Why this ordering
> <Why this is last: which dependencies had to be solid before you could attempt it.>

## Cross-cutting practices

> [!note] Maintain across all phases
> **Learning-mode discipline.** Whenever something is explained to you, write your own version in this vault; reformulating is where it sticks. Plan to implement about one feature in <N> entirely on your own (docs only, no assist) and log how it went.
>
> **ADR cadence.** Write an ADR whenever you make a decision you'd struggle to explain later. Target ≥1 per phase, more in <the phases with the biggest decisions>.
>
> **Commit message voice.** Write commits in your own voice. Past tense, imperative, consistent.
>
> **Working journal.** A dedicated note in this vault for "<the thing that kept tripping you up> today." Over time it becomes a debugging cheat-sheet.
>
> **Reference-reading discipline.** When stuck, read the primary resource or the official reference *before* searching. Stack Overflow is a last resort, not a first one.
